# Changelog

## 1.4.1-dev — Branded Public Website Integration

- Integrated the official Tempered Continuity logo and complete ember-to-blue identity system.
- Added generated Home, Run Forge, Documentation, Roadmap, Trust, Changelog, and Downloads pages for `forge.emotivus.com`.
- Made website content, limitations, commands, roadmap, and release status canonical through `FORGE-PRODUCT.json`.
- Added static deployment files, favicon, manifest, robots, sitemap, mobile navigation, copy controls, and website release documentation.
- Added planning and release contracts requiring the website to be rebuilt and checked with every Forge release.

## 1.4.1-dev — Run Forge First Target

- Made the natural first instruction simply **“Run Forge.”**
- Running Forge with no command now safely chooses Adopt + Resume, Resume, or Quick Check + Resume from current project state.
- Added a strict zero-command safety boundary: Ship, deployment, deletion, production migration, environment repair, and blocker bypass remain explicit-only operations.
- Added `RUN-FORGE.md` as the self-describing AI-session startup contract.
- Added host-project resolution that refuses to adopt Forge Core as its own target when no application source exists beside it.
- Preserved Help, Adopt, Resume, Check, and Ship as the complete public command set; smart start is launcher behavior, not a sixth command.
- Preserved the exact changed paths that triggered automatic Check in the final startup summary.

## 1.4.0-dev — Execution Ownership and Host-Termination Safety

- Replaced monolithic self-certification with isolated shards, automatically chunked large test classes, per-shard deadlines, immediate checkpoints, bounded host budgets, and fingerprint-safe resume.
- Added exclusive single-run ownership through an atomic process-owned run directory in the operating-system runtime area so concurrent certification fails immediately and project cleanup cannot erase ownership.
- Separated filtered diagnostic progress from authoritative full-suite progress.
- Replaced inherited output pipes with temporary-file capture and added a dedicated Forge shard runner so detached descendants and generic test-process cleanup cannot hold or kill the wrong run.
- Added SIGTERM and SIGINT cleanup that terminates the active shard process group and releases the execution lock when an external host stops Forge.
- Preserved every budget pause and external stop as `INCOMPLETE`; only a fully completed suite can report `PASS`.
- Made the self-test CLI compact by default, with complete evidence available through `--json` and checkpoint files.

## 1.4.0-dev — Project Passport Pivot

- Added five public commands: Help, Adopt, Resume, Check, and Ship.
- Initially made `forge help` the default when Forge was run without a command; 1.4.1-dev replaces that behavior with safe smart start.
- Kept `forge` as the canonical launcher and retained `frg` only as an optional name-conflict alias; both expose the same five commands.
- Added measured Resume token-efficiency reporting with explicit heuristic and truth boundaries.
- Added read-only project-state guidance, command topics, JSON output, and exact next-command recommendations.
- Added the Project Passport, Resume packet, ZIP-era changed-path tracking, change-aware Check, and Proof Card-oriented Ship facade.
- Consolidated Graph, Ledger, Context, Plan, Impact, Pivot, Learn, Guardrail, Gate, Lab, Evidence, runtime, confidentiality, delivery, and tool continuity beneath the five-command interface.
- Rebuilt onboarding, AI instructions, canonical product metadata, and the generated public website around the pivot.
- Preserved 1.3.x command routes as hidden compatibility and advanced controls.

## 1.4.0-dev execution-control hardening

- Replaced the monolithic Forge self-test command with isolated `unittest` class shards.
- Added per-shard process-group termination, explicit timeout classification, immediate checkpoints, and source-fingerprint-safe resume.
- Added `--budget-seconds`, `--per-shard-timeout`, `--resume`, `--fresh`, `--only`, and `--list` controls to the hidden self-test command.
- Execution-budget exhaustion now returns `INCOMPLETE` with a resume command instead of relying on the host to terminate Forge.
- Added neutral regressions for shard discovery, clean budget pause, and successful resume.
- Closed an unbounded post-timeout stdout read that could overrun the host budget when detached descendants inherited the shard pipe.
- Added cleanup reserve and minimum-start rules so a shard is not launched too close to wall-budget exhaustion.

## 1.3.6 — Confidential Tool Continuity

- Added metadata-only confidentiality configuration and schema-10 migration.
- Added generic and external-policy scans for secrets, private terms, file fingerprints, normalized text fingerprints, host paths, and ZIP members.
- Enforced confidentiality against the exact package source set and completed archives.
- Added typed tool ecosystem Graph nodes and relationships without raw command or host-content capture.
- Added metadata-only ecosystem lifecycle events for adoption, status changes, changed inputs, and stale evidence.
- Removed project-specific acceptance references and retained only synthetic neutral fixtures.
- Expanded the neutral regression suite to 167 tests.

## 1.3.5 — Host Tool Ecosystem Adoption

- Replaced script-by-script absorption as the preferred integration model with manifest-backed host tool ecosystem adoption.
- Added full working-set discovery across canonical tool source, configuration, tests, fixtures, baselines, allowlists, registries, release metadata, and bundled products.
- Registered only canonical automatic quick, section/toolset, and release profile commands while suppressing subordinate scripts already owned by the authoritative runner.
- Reused semantically equivalent existing commands, including commands with stricter `--fresh` execution, without duplicating them.
- Added dynamic ecosystem-input fingerprints to Gate command hashes so changed datasets, fixtures, manifests, or tool modules invalidate cached evidence.
- Blocked adopted commands before execution when a declared ecosystem input is missing or unsafe.
- Added generated-state discovery and in-place registry reports without copying or relocating producer-owned output.
- Added bundled-product boundaries so nested Forge distributions and other complete tools are summarized rather than mined for host checks.
- Made `adopt` the preferred CLI operation while preserving `absorb` as a legacy compatibility alias.
- Added seven permanent neutral regressions; the suite now declares 161 tests.
- Replaced external workspace-specific acceptance details with permanent synthetic neutral regressions.

## 1.3.4 — Neutral Acceptance and Exact Handoff Correction

- Allowed exact required package files to override ordinary deployment exclusions while preserving immutable, secret, and hard-block protections.
- Kept excluded ancestors traversable only to reach an exact required file and kept excluded siblings out.
- Deduplicated semantic executable Graph identities and stopped classifying conventional browser assets as server entrypoints.
- Added exact delivery-dimension diagnostics to compact Release Proof without converting those diagnostics into claim blockers.
- Added an explicit missing-final-bundle problem when artifacts are registered but no current owner-facing bundle exists.
- Invalidated the final-bundle receipt whenever a registered artifact is recorded or refreshed.
- Added final ZIP duplicate-path, member-presence, and member-byte SHA-256 verification.
- Added four permanent neutral regressions; the suite now declares 154 tests.
- Re-ran the unchanged Harbor Operations negative and remediated branches; the defect branch remained blocked and the control reached full Release Gate and exact-handoff PASS.
- Retired named internal applications and obsolete product snapshots from required Forge validation scope.

## 1.3.3 — Observed Evidence Attestation Hardening

- Closed a post-certification false-proof path where a generic passing command could declare blanket executable-surface coverage without reporting which surfaces it actually exercised.
- Added repeatable `FORGE_SURFACE:` observations to command evidence and exact surface attestations to successful Lab probes, Lab verification steps, and runtime-contract evidence.
- Changed Release Proof coverage joins to require both permitted declared scope and an exact current observed attestation.
- Bound target-environment and deployment-state evidence files to a named current registered Gate producer.
- Added Gate-managed artifact receipts with output SHA-256, byte count, and created-or-refreshed status.
- Rejected prewritten PASS evidence files when the named verifier did not create or refresh them during the current run.
- Rejected evidence files changed after their producer passed.
- Advanced project configuration to schema 9.
- Added five permanent regressions covering blank blanket claims, schema migration, observed marker/artifact capture, required missing artifacts, and prewritten evidence rejection; the neutral suite now declares 150 tests.

## 1.3.2 — Unfamiliar Plain-PHP Surface Correction

- Corrected external-project surface discovery after an unrelated PHP 8.4 acceptance fixture exposed under-mapped jobs and CLI tools, a mistyped webhook, and a helper-page false positive.
- Added path- and syntax-aware classification for PHP webhooks, scheduled jobs, and CLI entrypoints.
- Excluded conventional nested PHP support bootstraps from user-facing obligations unless they live under an explicit web root.
- Collapsed Graph and direct-discovery duplicates into one semantic proof obligation per path.
- Tightened Python CLI recognition to require a shebang or real `if __name__ == "__main__"` syntax rather than a keyword mention.
- Extended documentation-claim auditing to project-configured objective sources, with typed checks for execution, upgrade, and target-environment claims.
- Added two permanent recovery regressions; the neutral suite now declares 145 tests.
- Recorded that the concealed mini applications were unavailable and not used for that release; they are now retired from required validation scope.

## 1.3.1 — Assurance Coverage and Delivery Provenance

- Added scoped release claim levels instead of one undifferentiated green release result.
- Added broad executable-surface discovery and recurring surface-to-evidence coverage.
- Added typed command, Lab, and runtime-contract evidence bound to current source and producer fingerprints.
- Added target-environment proof distinct from local Doctor and deployment-state matrices for prior persisted state plus current code.
- Added detection of one-time documentation verification claims without recurring evidence.
- Added first-class delivery provenance for multi-artifact owner handoffs.
- Added Forge-observed generator execution, source-input and generator fingerprints, output hashes, and drift rejection.
- Added undeclared-deliverable detection, current-role disambiguation, exact final-bundle membership, and two-phase handoff gating.
- Added Graph relationships from source inputs to delivered artifacts and final bundles.
- Added Release Proof and delivery provenance to Evidence and deployment manifests.
- Added 14 recovery regressions based on two field-failure classes, without inspecting the concealed future-validation fixtures.
- Advanced project configuration to schema 8.

## 1.3.0 — Runtime and User-Behavior Proof

- Added project-owned runtime contracts under Prove → Lab.
- Added explicit authorization matrices covering allowed/denied access, denied mutations, CSRF, explicit deny, privilege administration, and session revocation.
- Bound evidence to the active contract fingerprint and evidence boundary; stale proof is rejected and credential-like output is redacted.
- Added ordered migration/schema dependency analysis, excluded-predecessor detection, and executable first-run/idempotency/data-preservation coverage.
- Added browser and integration runner discovery without replacing existing Playwright, Cypress, Selenium, or project-specific tools.
- Split Impact into certification, dependency-reach, and runtime-path claims so file-level reach is not presented as branch-level proof.

# Emotivus Forge Changelog

## 1.2.1 — Lab Truthfulness

- Replaced status-only Lab success claims with explicit evidence levels: process, connectivity, content readiness, stateful behavior, environment-backed behavior, and release-equivalent proof.
- Added required and forbidden body assertions, regular expressions, content-type and header checks, body-size thresholds, final-URL checks, and JSON-path assertions.
- Added readiness fingerprints while avoiding storage of full response bodies.
- Added ordered HTTP journeys with shared cookies and captured response state.
- Added executable, file, environment-variable, and service prerequisites; unavailable prerequisites now return BLOCKED.
- Added minimum Lab evidence requirements by Gate profile so status-only release probes cannot certify application readiness.
- Added internal-delivery and Lab-workspace cache pruning for `__pycache__`, bytecode, and common Python tool caches.
- Added regressions reproducing a real HTTP 200 error-page false green and verifying stateful journey evidence.
- Advanced project configuration to schema 6.

## 1.1.1 — Understand, Change, Prove

- Consolidated the public experience into three clear cores while retaining named tools and all detailed v1.0 commands as compatible advanced aliases.
- Added **Understand** with Start, Brief, Graph, Ledger, Context, and Doctor.
- Added **Change** with Plan, Impact, Pivot, Learn, and Guardrail.
- Added **Prove** with Gate, Lab, Evidence, Deliver, Mirror, and CI.
- Added one canonical project-memory layer for bounded plans, durable records, source-of-truth artifacts, token-aware context packets, and strategic pivots.
- Added compact, standard, and full context budgets with source references and retrieval paths for minimum sufficient verified context.
- Added broad Change-plan quality targets for security, reliability, performance, efficiency, accessibility, user experience, maintainability, compatibility, and privacy, plus project-defined standards references and exceptions.
- Added explicit pivot assessment, obligation disposition, pre-pivot checkpoints, exploration mode, and replacement-evidence requirements.
- Added direct Proof Evidence listing and inspection for Gate reports, execution history, and deterministic failure bundles.
- Added release-facing project-truth validation and portable project memory inside Forge State.
- Added development and lean public editions generated from the same source and certified through Mirror.
- Reworked public documentation around Why Forge and the three-core model without hiding the underlying functional tools.
- Expanded the neutral regression inventory to 91 tests and the active self-hosting contract inventory to 25.

## 1.0.6 — Maintenance and Distribution

- Added Forge Update preview, backup, schema migration, private extension preservation, post-update verification, automatic rollback, and explicit rollback.
- Added reviewed reversible Doctor remediation for declared filesystem repairs.
- Added CI Bridge generation for GitHub Actions, GitLab CI, shell, and cPanel-oriented release workflows.
- Added separate deployment and internal package profiles, pairing internal source with portable Forge State.
- Advanced project configuration to schema 2 with migration evidence and backup.
- Extended Mirror consumer acceptance to exercise v1.0.6 maintenance and delivery capabilities from the extracted release.

## 1.0.5 — Evidence and Guardrails

- Added explicit PASS, FAIL, SKIP, ERROR, and NOT-RUN execution states.
- Added optional marker-based status, assertion, migration, skip, and executed-command evidence.
- Added changed-since-green failure context bundles with Graph, Learn, Doctor, and reproduction evidence.
- Added expected-layout and environment preflight before absorbed host commands run.
- Added historical execution anomaly tracking keyed by environment and command fingerprint.
- Added reviewed one-run anomaly overrides without permanent suppression.
- Added Guardrail proposals for resolved zero-byte, hostile-filename, required/forbidden artifact, and required/forbidden content anomalies.
- Added case-insensitive and Unicode-normalization package-collision blocking.
- Added exclusive Mirror ownership locking to prevent concurrent certification against one archive path.
- Added permanent regressions for missing evidence, explicit SKIPs, NOT-RUN completeness, layout preflight, failure bundles, anomaly blocking, and guardrail activation.

## 1.0.4 — First Contact and Continuity

- Added a copy-ready AI bootstrap prompt to every initialized project and documented the required installation direction: Forge remains a separate assurance layer and is never merged into host application code.
- Added **Forge Brief**, a deterministic session-start digest covering objective, version, last green Gate, source fingerprint status, Graph summary, learned contracts, Doctor status, and recovery commands.
- Added portable **Forge State** export, inspection, and adoption for no-Git and ZIP-based workflows, including manifests, SHA-256 validation, secret blocking, project-identity checks, and pre-adoption backups.
- Added the **Forge Doctor foundation** for required runtimes, absorbed-command executables, environment-variable names, and expected workspace-layout contracts. Doctor emits a repair plan and performs no automatic repair.
- Rewrote existing-tool classification to require affirmative CLI/tooling evidence, expose a uniform `classification` field, and retain application runtime files or PHP files included by web entry points.
- Added plain-PHP version detection for `define('*_VERSION', '...')` and `const *_VERSION = '...'` patterns without inventing an npm package manager when no package manifest exists.
- Added declared and absorbed non-conventional test entry points as valid test evidence.
- Replaced whitespace-tolerant conflict-marker regexes with a context-aware lexical scanner that ignores markers in strings, docstrings, comments, heredocs, template literals, and Markdown fences while retaining column-zero blockers.
- Added host-mode self-isolation evidence and scoped exclusion guidance for mature project documentation, test, static-analysis, security, and packaging tools.
- Added audit warnings and package blockers for hostile or non-portable filenames and unexpected zero-byte files, with explicit placeholder exceptions.
- Added deployment exclusion for `Forge-State*.zip`.
- Expanded the neutral regression suite from 54 to 65 tests, including exact first-real-project field-report regressions.

## 1.0.3 — Forge Mirror and mandatory self-hosting

- Added **Forge Mirror**, a production-only self-hosting pipeline that requires Forge to initialize, inventory, map, impact-analyze, audit, Lab-test, Gate, package, extract, retest, and consume itself before a Forge release is certified.
- Added **Forge Bootstrap**, a deliberately independent standard-library validator that imports no Forge modules and verifies Python syntax, JSON, canonical paths, version agreement, CLI startup, self-tests, archive shape, extraction, and checksums.
- Added first-party Forge identity detection so active Forge Core files and certification tests are retained rather than misclassified as competing tools during self-audit.
- Added general Python version detection for `pyproject.toml`, `setup.cfg`, `setup.py`, root or package `__init__.py`, including Forge's canonical `__version__` source.
- Added version-controlled self-hosting contracts under `self/learned-contracts.json`; Mirror points Forge Learn at these permanent invariants.
- Added Forge-specific disposable Labs for CLI lifecycle, human documentation HTTP serving, and independent bootstrap execution; the complete regression suite remains a dedicated Section Gate command.
- Replaced literal private-key-marker matching with context-aware PEM block recognition. Detector definitions no longer trigger false blockers, while actual PEM structures remain blockers.
- Added narrow declared synthetic-secret and synthetic-private-key annotations and configured fixture paths; no file-level security exemption is created.
- Added archive extraction and fresh neutral consumer acceptance to the production release chain.
- Added Markdown and human-web documentation for Mirror and a prioritized internal roadmap.
- Expanded the neutral regression suite from 42 to 54 tests.

## 1.0.2 — Project intelligence: Graph, Learn, and Lab

- Added **Forge Graph**, a neutral architecture mapper for files, entry points, routes, dependencies, tests, migrations, configuration, environment variables, external hosts, webhooks, scheduled jobs, database indicators, authentication flows, and upload flows.
- Added **Forge Impact**, which calculates change blast radius from explicit or Git-detected changed paths, assigns a risk level, identifies affected subsystems, finds linked tests, and recommends Forge Gates and live verification.
- Added Graph refresh to the Section and Release Gates by default.
- Added **Forge Learn**, a proposal-first defect-memory system that records symptom, verified root cause, approved fix, invariant, affected paths, mapped subsystems, gate, and regression.
- Added explicit approval and rejection of Learn proposals; proposals never activate automatically.
- Added learned regression types for file existence, required or forbidden content, JSON values, architecture nodes, project commands, and manual verification.
- Added audit enforcement of approved static learned contracts and profile registration of approved command contracts.
- Made learned-contract violations non-baselinable, including warning-level contracts.
- Added **Forge Lab**, with disposable copied workspaces, ephemeral localhost ports, setup commands, service start, repeated HTTP probes, verification commands, teardown, process-group termination, evidence reports, and optional failure preservation.
- Added safe inferred smoke recipes for static sites and PHP built-in-server projects.
- Added optional assignment of Lab recipes to Section or Release Gates and explicit failure when a required Gate has no recipe.
- Extended guided and answers-file setup with Graph, Learn, and Lab decisions.
- Extended existing-tool detection for dependency graphers, impact-analysis scripts, defect ledgers, Playwright, Cypress, Selenium, Puppeteer, Docker smoke environments, and related tools.
- Preserved specialized overlapping tools by default; Forge orchestrates or reviews them rather than assuming redundancy.
- Expanded the human documentation website and Markdown documentation for installation, architecture, impact analysis, defect memory, and disposable verification.
- Expanded the neutral regression suite from 28 to 42 tests.

## 1.0.1 — Neutral initial configuration and tool migration

- Removed every project-specific policy pack, regression, recovery utility, historical snapshot, name, version constant, path, and documentation reference from the portable distribution.
- Added a guided first-run configuration covering assurance preset, deployment target, versioning, tests, documentation, warning policy, inherited-debt baseline, existing-tool handling, required package files, and live verification categories.
- Added repeatable answers-file initialization and direct CLI overrides.
- Added existing-tool inventory for package-manager scripts, quality scripts, CI workflows, configuration files, release tooling, packagers, deployment scripts, secret scanners, and AI-agent instructions.
- Added retain, absorb, review, and replace classifications.
- Added safe command absorption into quick, section, and release profiles without deleting source implementations.
- Added lockfile-aware npm, pnpm, Yarn, and Bun orchestration plus Composer quality-script absorption.
- Added explicit confirmed “remove” behavior as reversible quarantine under `.forge/legacy-tools/`, including original paths and SHA-256 restoration evidence.
- Added tool inventory and migration-plan reports to every initial run.
- Added a self-contained responsive human documentation website with install, configuration, migration, workflow, file, safety, and FAQ guidance.
- Added a `docs` CLI command that returns the local documentation path or serves the site.
- Expanded the neutral regression suite to cover configuration, migration, reversible quarantine, documentation, neutrality, packaging, release, resume, and baseline behavior.

## 1.0.0 — Reusable Forge Core

- Established the neutral auditing, baseline, release, runner, reporting, adapter, and packaging architecture.
- Added PHP, JavaScript, CSS, Apache/cPanel, Node.js, and Python adapters.
- Added resumable quality profiles with source-tree and command fingerprints.
- Added deployment manifests, secret scanning, immutable exclusions, symlink refusal, and release metadata enforcement.

## 1.2.0 — Controlled Change and Pivot maturity

- Added formal exploration, transition, development, and release modes inside Change → Pivot.
- Added structured obligations with enduring, architecture-bound, temporary, and experimental stability.
- Expanded lifecycle dispositions to retain, revise, suspend, replace, retire, restore, and supersede.
- Added hash-verified pre-pivot assurance checkpoints and reviewed assurance-state restoration without claiming source restoration.
- Added one linked transition Plan for every activated Pivot.
- Added Plan updates, quality-evidence coverage, and release blocking for unresolved required quality dimensions.
- Added versioned standards records in the Ledger with source, version, authority, scope, review metadata, and replacement history.
- Added successor, reason, replacement-evidence, release-mode, and current Release Gate requirements to the Pivot completion boundary.
- Pivot completion now applies lifecycle changes to learned contracts and Ledger records.
- Added Pivot-aware context packets, examples, public documentation, and permanent self-contracts.
