# Emotivus Forge 1.4.1-dev — Implementation Report

## Purpose

Reduce first contact to one natural instruction:

> **Run Forge.**

The public product still has exactly five commands: Help, Adopt, Resume, Check, and Ship. Smart start is launcher behavior, not a sixth command.

## Implemented startup state machine

- Not adopted or incomplete: initialize safely, build the Project Passport, checkpoint the project, and generate Resume.
- Adopted and unchanged: generate Resume without repeating adoption.
- Adopted and changed: preserve the triggering changed paths, run Quick Check, checkpoint, and generate Resume.
- No host project beside Forge: stop without creating project state.

## Safety boundary

Smart start cannot automatically:

- Ship or deploy;
- delete files or data;
- run production migrations;
- apply environment repairs;
- bypass a failed Check or unsupported claim.

## Outputs

- `.forge/passport/passport.json`
- `.forge/passport/passport.md`
- `.forge/passport/resume.json`
- `.forge/passport/resume.md`
- `.forge/passport/run-latest.json`
- `.forge/passport/check.json` when changed files trigger Quick Check

## Packaging and onboarding

`RUN-FORGE.md` is included in development and public distributions. README, Quickstart, First Contact, AI Agent Instructions, Help documentation, product metadata, roadmap, changelog, and generated website were updated from the same operating contract.

## Remaining development

The first-target package is ready for field adoption and continuity testing. Reliable multi-pass surface inventory, confidence correction, graph-to-evidence joins, and exact Ship expansion remain roadmap work.
## Public website integration

The 1.4.1-dev release tree now includes the official Tempered Continuity identity and a generated, responsive public website targeting `forge.emotivus.com`. The website is release-bound through `FORGE-PRODUCT.json`; it is not maintained as an independent marketing copy fork.

