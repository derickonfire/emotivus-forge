#!/usr/bin/env python3
"""Build a portable Emotivus Forge ZIP from FORGE-MANIFEST.json."""
from __future__ import annotations

import argparse
import glob
import hashlib
import json
import os
import stat
import sys
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Iterable

EXCLUDED_PARTS = {"__pycache__", ".git", ".release-checks", ".forge", ".runtime", "deploy"}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def safe_zip_datetime(timestamp: float) -> tuple[int, int, int, int, int, int]:
    dt = datetime.fromtimestamp(timestamp)
    return (min(max(dt.year, 1980), 2107), dt.month, dt.day, dt.hour, dt.minute, dt.second)


def iter_directory(root: Path, directory: Path) -> Iterable[Path]:
    for current, dir_names, file_names in os.walk(directory):
        current_path = Path(current)
        dir_names[:] = [name for name in sorted(dir_names) if name not in EXCLUDED_PARTS]
        for name in sorted(file_names):
            path = current_path / name
            relative = path.relative_to(root)
            if any(part in EXCLUDED_PARTS for part in relative.parts):
                continue
            if path.is_file() and not path.is_symlink():
                yield path


def expand_manifest(root: Path, patterns: list[str]) -> list[Path]:
    included: dict[str, Path] = {}
    for raw in patterns:
        if not isinstance(raw, str) or not raw.strip():
            raise RuntimeError("canonical_paths entries must be non-empty strings")
        pattern = raw.strip().replace("\\", "/")
        if pattern.startswith("/") or ".." in Path(pattern).parts:
            raise RuntimeError(f"unsafe Forge path: {pattern}")
        candidate = root / pattern.rstrip("/")
        if pattern.endswith("/"):
            if not candidate.is_dir():
                raise RuntimeError(f"required Forge directory missing: {pattern}")
            matches = list(iter_directory(root, candidate))
        elif any(char in pattern for char in "*?["):
            matches = [Path(item) for item in glob.glob(str(root / pattern), recursive=True)]
            matches = [item for item in matches if item.is_file() and not item.is_symlink()]
            if not matches:
                raise RuntimeError(f"Forge pattern matched no files: {pattern}")
        else:
            if not candidate.is_file():
                raise RuntimeError(f"required Forge file missing: {pattern}")
            matches = [candidate]
        for path in matches:
            relative = path.relative_to(root).as_posix()
            if any(part in EXCLUDED_PARTS for part in Path(relative).parts):
                continue
            included[relative] = path
    return [included[key] for key in sorted(included)]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", nargs="?", default=".")
    parser.add_argument("--manifest", default="FORGE-MANIFEST.json")
    parser.add_argument("--output", default="deploy/Emotivus-Forge.zip")
    parser.add_argument("--edition", choices=("development", "public"), default="development")
    parser.add_argument("--private-policy", default=os.environ.get("FORGE_PRIVATE_POLICY", ""), help="Optional external confidentiality denylist; never packaged")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    manifest_path = Path(args.manifest)
    if not manifest_path.is_absolute():
        manifest_path = root / manifest_path
    output = Path(args.output)
    if not output.is_absolute():
        output = root / output
    try:
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
        if data.get("forge_schema") != 1:
            raise RuntimeError("FORGE-MANIFEST.json must use forge_schema 1")
        path_key = "public_paths" if args.edition == "public" else "canonical_paths"
        patterns = data.get(path_key)
        if not isinstance(patterns, list):
            raise RuntimeError(f"{path_key} must be an array")
        archive_root = data.get("archive_root", "Emotivus-Forge")
        if not isinstance(archive_root, str) or not archive_root.strip():
            raise RuntimeError("archive_root must be a non-empty string")
        archive_root = archive_root.strip().strip("/\\")
        if not archive_root or ".." in Path(archive_root).parts:
            raise RuntimeError("archive_root must be a safe relative path")
        files = expand_manifest(root, patterns)
        sys.path.insert(0, str(root))
        from emotivus_forge.confidentiality import scan_confidentiality, scan_zip_archive
        policy_path = Path(args.private_policy).resolve() if args.private_policy else root / "CONFIDENTIALITY-POLICY.json"
        neutrality = scan_confidentiality(root, policy_path=policy_path, paths=files, write=False, scan_archives=True)
        if neutrality.get("status") != "PASS":
            raise RuntimeError(f"confidentiality scan failed with {len(neutrality.get('findings', []))} finding(s)")
    except (OSError, json.JSONDecodeError, KeyError, RuntimeError) as exc:
        print(f"FORGE PACKAGE: BLOCKED — {exc}", file=sys.stderr)
        return 1
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".tmp")
    if temporary.exists():
        temporary.unlink()
    try:
        with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for path in files:
                relative = path.relative_to(root).as_posix()
                archive_name = f"{archive_root}/{relative}"
                info = zipfile.ZipInfo(archive_name, safe_zip_datetime(path.stat().st_mtime))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = (stat.S_IMODE(path.stat().st_mode) & 0xFFFF) << 16
                content = path.read_bytes()
                if args.edition == "public" and relative == "FORGE-MANIFEST.json":
                    public_manifest = dict(data)
                    public_manifest["state"] = "public-preview"
                    public_manifest["edition"] = "public"
                    public_manifest["canonical_paths"] = list(data.get("public_paths", []))
                    content = (json.dumps(public_manifest, indent=2) + "\n").encode("utf-8")
                archive.writestr(info, content)
        archive_scan = scan_zip_archive(temporary, policy_path=policy_path)
        if archive_scan.get("status") != "PASS":
            raise RuntimeError(f"built archive confidentiality scan failed with {len(archive_scan.get('findings', []))} finding(s)")
        temporary.replace(output)
    except (OSError, RuntimeError, zipfile.BadZipFile) as exc:
        print(f"FORGE PACKAGE: BLOCKED — {exc}", file=sys.stderr)
        return 1
    finally:
        if temporary.exists():
            temporary.unlink()
    print(f"FORGE PACKAGE ({args.edition}): PASS")
    print(f"Files: {len(files)}")
    print(f"Output: {output}")
    print("Confidentiality: PASS")
    print(f"SHA-256: {sha256_file(output)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
