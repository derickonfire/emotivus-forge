# Run Forge

## The only first instruction

> **Run Forge.**

For an AI coding session, those two words are the complete user-facing startup instruction.

## What the active AI must do

1. Identify the target project's complete working source. If the target is still a ZIP, extract it safely first.
2. Extract this Forge ZIP so `Emotivus-Forge/` sits inside the target project's working root.
3. Work from the target-project root—not from inside `Emotivus-Forge/`.
4. Run Forge with no command:

```bash
python3 Emotivus-Forge/forge.py
```

Windows fallback:

```bat
Emotivus-Forge\forge.cmd
```

5. Read the generated `.forge/passport/resume.md` before changing project files.
6. Report Forge blockers, uncertainty, and the current objective honestly.

## What Forge chooses automatically

- New or incomplete project: **Adopt + Resume**
- Adopted and unchanged project: **Resume**
- Adopted project with changed files: **Quick Check + Resume**

## Safety boundary

“Run Forge” never automatically:

- Ships or deploys a release;
- deletes files or data;
- executes production migrations;
- applies environment repairs;
- bypasses a failed Check or unsupported release claim.

Those actions require an explicit owner instruction and, where applicable, an explicit Forge command.

## When Forge cannot find the project

Forge stops without modifying anything and explains where the target project must be extracted. Do not point Forge at its own internal directory as though Forge Core were the host project.

## The five public commands still exist

`Help`, `Adopt`, `Resume`, `Check`, and `Ship` remain the complete public command set. “Run Forge” is the zero-friction launcher behavior, not a sixth command.
