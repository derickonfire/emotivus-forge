# Forge Public Website

Official target: `https://forge.emotivus.com`

The public website is generated from the canonical root file `FORGE-PRODUCT.json`.

```bash
python3 docs-site/build_site.py
python3 forge.py docs --serve
```

To create the standalone deployable website with the latest public package:

```bash
python3 docs-site/build_site.py \
  --download /path/to/RUN-FORGE.zip \
  --release-notes /path/to/RELEASE-NOTES.md \
  --checksums /path/to/SHA256SUMS.txt
```

The site structure is:

- Home
- Run Forge
- Documentation
- Roadmap
- Trust
- Changelog
- Downloads

A development release is incomplete when the generated site advertises an older version, command set, roadmap, limitation, trust boundary, domain, or download.
