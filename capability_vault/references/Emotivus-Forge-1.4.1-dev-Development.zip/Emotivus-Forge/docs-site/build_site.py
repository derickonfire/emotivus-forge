#!/usr/bin/env python3
"""Generate the public Forge website from canonical FORGE-PRODUCT.json metadata."""
from __future__ import annotations

import argparse
import hashlib
import html
import json
import shutil
from pathlib import Path
from urllib.parse import quote

ROOT = Path(__file__).resolve().parents[1]
SITE = ROOT / "docs-site"
ASSETS = SITE / "assets"
PRODUCT_PATH = ROOT / "FORGE-PRODUCT.json"
PRODUCT = json.loads(PRODUCT_PATH.read_text(encoding="utf-8"))
WEB = PRODUCT["website"]
VERSION = PRODUCT["version"]
BASE_URL = WEB["base_url"].rstrip("/")


def esc(value: object) -> str:
    return html.escape(str(value), quote=True)


def asset_prefix(depth: int) -> str:
    return "../" * depth


def logo(prefix: str = "") -> str:
    return f'''<span class="brand-mark" aria-hidden="true"><img src="{prefix}assets/forge-mark.svg" alt=""></span><span class="brand-copy"><strong>FORGE</strong><small>Emotivus</small></span>'''


def wordmark(prefix: str = "") -> str:
    return f'''<div class="wordmark" aria-label="Emotivus Forge"><div class="wordmark-main"><span>F</span><img class="wordmark-o" src="{prefix}assets/forge-mark.svg" alt="O"><span>RGE</span></div><span class="wordmark-parent">Emotivus</span></div>'''


def canonical(path: str) -> str:
    path = path.strip("/")
    return f"{BASE_URL}/{path + '/' if path else ''}"


def nav(prefix: str, current: str) -> str:
    items = [
        ("Home", f"{prefix}index.html", "home"),
        ("Run Forge", f"{prefix}run/index.html", "run"),
        ("Documentation", f"{prefix}docs/index.html", "docs"),
        ("Roadmap", f"{prefix}roadmap/index.html", "roadmap"),
        ("Trust", f"{prefix}trust/index.html", "trust"),
    ]
    links = "".join(
        f'<a href="{href}"' + (' aria-current="page"' if key == current else "") + f'>{label}</a>'
        for label, href, key in items
    )
    return f'''<header class="topbar"><div class="shell nav"><a class="brand" href="{prefix}index.html" aria-label="Emotivus Forge home">{logo(prefix)}</a><button class="menu-toggle" type="button" data-menu-toggle aria-expanded="false" aria-controls="primary-links">Menu</button><nav class="links" id="primary-links" data-nav-links aria-label="Primary">{links}<a class="nav-download" href="{prefix}downloads/RUN-FORGE.zip">Download</a></nav></div></header>'''


def footer(prefix: str = "") -> str:
    return f'''<footer class="footer"><div class="shell"><div class="footer-grid"><div><a class="brand" href="{prefix}index.html">{logo(prefix)}</a><p>{esc(PRODUCT['tagline'])}</p><p class="site-domain">forge.emotivus.com</p></div><div><strong>Product</strong><div class="footer-links"><a href="{prefix}run/index.html">Run Forge</a><a href="{prefix}docs/index.html">Documentation</a><a href="{prefix}roadmap/index.html">Roadmap</a><a href="{prefix}changelog/index.html">Changelog</a></div></div><div><strong>Trust</strong><div class="footer-links"><a href="{prefix}trust/index.html">Privacy and boundaries</a><a href="{prefix}downloads/SHA256SUMS.txt">Checksums</a><a href="{prefix}downloads/RELEASE-NOTES.md">Release notes</a><a href="https://emotivus.com">Emotivus.com</a></div></div></div><div class="footer-bottom"><span>Emotivus Forge · {esc(VERSION)} · Development Preview</span><span>Local-first · Portable · Model-independent</span><span>© <span data-year></span> Emotivus</span></div></div></footer>'''


def shell(title: str, description: str, body: str, *, current: str, depth: int = 0, path: str = "") -> str:
    prefix = asset_prefix(depth)
    full_title = f"{title} — Emotivus Forge"
    url = canonical(path)
    structured = {
        "@context": "https://schema.org",
        "@type": "SoftwareApplication",
        "name": "Emotivus Forge",
        "applicationCategory": "DeveloperApplication",
        "operatingSystem": "Portable local command line",
        "softwareVersion": VERSION,
        "url": BASE_URL,
        "description": PRODUCT["summary"],
        "isPartOf": {"@type": "WebSite", "name": "Emotivus", "url": "https://emotivus.com"},
    }
    return f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#090706">
<title>{esc(full_title)}</title>
<meta name="description" content="{esc(description)}">
<link rel="canonical" href="{esc(url)}">
<link rel="icon" href="{prefix}assets/favicon.svg" type="image/svg+xml">
<link rel="manifest" href="{prefix}site.webmanifest">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Emotivus Forge">
<meta property="og:title" content="{esc(full_title)}">
<meta property="og:description" content="{esc(description)}">
<meta property="og:url" content="{esc(url)}">
<meta name="twitter:card" content="summary">
<link rel="stylesheet" href="{prefix}assets/styles.css">
<script type="application/ld+json">{json.dumps(structured, separators=(',', ':'))}</script>
<script src="{prefix}assets/app.js" defer></script>
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
{nav(prefix, current)}
{body}
{footer(prefix)}
</body>
</html>'''


def command_cards() -> str:
    return "".join(
        f'''<article class="card command-card"><span class="num">0{index}</span><h3>{esc(item['name'])}</h3><p>{esc(item['description'])}</p><code>{esc(item['command'])}</code></article>'''
        for index, item in enumerate(PRODUCT["public_commands"], start=1)
    )


def home() -> str:
    body = f'''<main id="main">
<section class="hero"><div class="shell hero-grid"><div><p class="eyebrow">Project continuity for AI-built software</p><h1>Keep the project.<br><span>Lose the chaos.</span></h1><p class="lead">{esc(PRODUCT['summary'])}</p><div class="actions"><a class="button primary" href="run/index.html">Run Forge</a><a class="button secondary" href="docs/index.html">Read the documentation</a></div><p class="release-note"><b>{esc(VERSION)}</b> · Development preview for real-project continuity testing.</p></div><aside class="forge-console" aria-label="Example Forge startup result"><div class="console-head"><span>Current project state</span><strong>Passport ready</strong></div><div class="console-logo">{wordmark()}</div><div class="console-body"><div class="console-line"><span>Instruction</span><strong>Run Forge.</strong></div><div class="console-line"><span>Action</span><strong class="good">ADOPT + RESUME</strong></div><div class="console-line"><span>Project Passport</span><strong>Created</strong></div><div class="console-line"><span>Current objective</span><strong>Identified</strong></div><div class="console-line"><span>Next action</span><strong class="blue">Read Resume packet</strong></div></div></aside></div></section>
<section class="section alt"><div class="shell"><div class="section-head"><div><p class="eyebrow">The first instruction</p><h2>Upload it. Say <span class="gradient-text">“Run Forge.”</span></h2></div><p>Forge chooses the safe startup action from the project state. It does not require the user to understand its internal assurance machinery before benefiting from it.</p></div><div class="run-flow"><article class="run-step"><b>1</b><h3>Upload the project</h3><p>Use the complete current project ZIP or extracted working folder.</p></article><article class="run-step"><b>2</b><h3>Add RUN-FORGE.zip</h3><p>Forge remains separate from the application and creates portable project state beside it.</p></article><article class="run-step"><b>3</b><h3>Tell the AI: Run Forge.</h3><p>Forge adopts, resumes, or checks the project, then gives the active AI the correct bounded context.</p></article></div><div class="prompt-box"><small>Canonical chat instruction</small><div class="prompt-row"><code>Run Forge.</code><button class="copy" type="button" data-copy="Run Forge.">Copy</button></div></div></div></section>
<section class="section"><div class="shell"><div class="section-head"><div><p class="eyebrow">Why Forge exists</p><h2>A durable project brain around any coding AI.</h2></div><p>Forge is not a competing coding model. It is the continuity, structure, change-control, and proof layer that keeps large AI-assisted projects understandable between sessions.</p></div><div class="grid-3"><article class="card"><span class="num">01</span><h3>Project Passport</h3><p>Records identity, structure, objectives, decisions, risks, evidence, uncertainty, and the next action in one portable project truth.</p></article><article class="card"><span class="num">02</span><h3>Minimum sufficient context</h3><p>Resume gives each new AI session the relevant project truth instead of repeatedly rediscovering the entire codebase.</p></article><article class="card"><span class="num">03</span><h3>Honest release proof</h3><p>Forge separates source checks, execution, upgrade state, target environment, confidentiality, and final delivery evidence.</p></article></div></div></section>
<section class="section alt"><div class="shell"><div class="section-head"><div><p class="eyebrow">Simple outside, powerful underneath</p><h2>Five commands. One Project Passport. Any coding AI.</h2></div><p>Advanced Graph, Ledger, Lab, runtime, evidence, and delivery systems remain available beneath a deliberately small public interface.</p></div><div class="five-grid">{command_cards()}</div></div></section>
<section class="section"><div class="shell"><div class="section-head"><div><p class="eyebrow">Current development status</p><h2>Useful now. Honest about what is still being hardened.</h2></div><p>Forge can already control continuity and ZIP-era changes on real projects. Complete multi-pass surface discovery remains active development.</p></div><div class="status-table"><div class="status-row"><strong>Project continuity</strong><span class="available">Available for testing</span><span>Passport, Resume, objectives, durable records, and next actions.</span></div><div class="status-row"><strong>Smart startup</strong><span class="available">Available</span><span>New project: Adopt + Resume. Changed project: Quick Check + Resume.</span></div><div class="status-row"><strong>ZIP workflow</strong><span class="available">Available</span><span>Git is not required during the current development cycle.</span></div><div class="status-row"><strong>Complete surface discovery</strong><span class="development">In development</span><span>Classification confidence and multi-pass convergence are still being strengthened.</span></div><div class="status-row"><strong>Commercial release</strong><span class="future">Future</span><span>Forge is not yet the sole production-readiness authority.</span></div></div></div></section>
<section class="section alt"><div class="shell"><div class="trust-strip"><div><b>Local-first</b><span>Project source stays with the project.</span></div><div><b>Model-independent</b><span>Use Claude, ChatGPT, Cursor, or human developers.</span></div><div><b>Neutral</b><span>Public Forge contains no customer or private project data.</span></div><div><b>Exact claims</b><span>Unknown and unproven remain visible.</span></div></div></div></section>
</main>'''
    return shell("Project memory and proof", PRODUCT["tagline"], body, current="home", path="")


def run_page() -> str:
    body = f'''<main id="main"><section class="page-hero"><div class="shell"><p class="eyebrow">Run Forge</p><h1>One instruction starts the right workflow.</h1><p class="lead">Upload the target project and <code>RUN-FORGE.zip</code>, then tell the active coding AI: <strong>Run Forge.</strong></p><div class="actions"><a class="button primary" href="../downloads/RUN-FORGE.zip">Download RUN-FORGE.zip</a><a class="button secondary" href="../downloads/SHA256SUMS.txt">Verify checksum</a></div></div></section><section class="section"><div class="shell"><div class="run-flow"><article class="run-step"><b>1</b><h3>Provide the complete project</h3><p>Use the current full ZIP or extracted source—not only a changed-files patch.</p></article><article class="run-step"><b>2</b><h3>Provide RUN-FORGE.zip</h3><p>The active AI extracts Forge beside the target application and runs from the project root.</p></article><article class="run-step"><b>3</b><h3>Say “Run Forge.”</h3><p>The smart launcher chooses the safe startup action and returns a compact project briefing.</p></article></div><div class="prompt-box"><small>Use this exact instruction</small><div class="prompt-row"><code>Run Forge.</code><button class="copy" type="button" data-copy="Run Forge.">Copy</button></div></div></div></section><section class="section alt"><div class="shell"><div class="section-head"><div><p class="eyebrow">Automatic behavior</p><h2>Forge reads the project state before choosing the action.</h2></div><p>Smart startup is launcher behavior, not a sixth command. The complete public command interface remains Help, Adopt, Resume, Check, and Ship.</p></div><div class="grid-3"><article class="card"><span class="num">NEW</span><h3>Adopt + Resume</h3><p>No complete Passport exists. Forge inventories the project, creates continuity state, and generates the first Resume packet.</p></article><article class="card"><span class="num">KNOWN</span><h3>Resume</h3><p>The project is already adopted and unchanged. Forge gives the active session the bounded current truth.</p></article><article class="card"><span class="num">CHANGED</span><h3>Quick Check + Resume</h3><p>File hashes changed. Forge records the changed paths, invalidates stale evidence, performs a bounded check, and refreshes context.</p></article></div></div></section><section class="section"><div class="shell grid-2"><article class="card"><span class="num">SAFE BY DEFAULT</span><h3>Smart startup never automatically:</h3><ul><li>Ships or deploys a release</li><li>Deletes project files</li><li>Runs production migrations</li><li>Repairs the environment</li><li>Bypasses a blocker</li></ul></article><article class="card"><span class="num">OUTPUT</span><h3>What the active AI receives</h3><ul><li>Project Passport</li><li>Current objective and decisions</li><li>Changed paths and evidence gaps</li><li>Relevant files and architecture</li><li>One recommended next action</li></ul></article></div></section><section class="section alt"><div class="shell"><div class="forge-console"><div class="console-head"><span>Example first target</span><strong>Safe startup complete</strong></div><div class="console-body"><div class="console-line"><span>Project</span><strong>Your Project</strong></div><div class="console-line"><span>Action completed</span><strong class="good">ADOPT + RESUME</strong></div><div class="console-line"><span>Project Passport</span><strong>Created</strong></div><div class="console-line"><span>Known risks</span><strong>3</strong></div><div class="console-line"><span>Current proof</span><strong>Not yet established</strong></div><div class="console-line"><span>Next action</span><strong class="blue">Read the Resume packet</strong></div></div></div></div></section></main>'''
    return shell("Run Forge", "Upload the project, add RUN-FORGE.zip, and say Run Forge.", body, current="run", depth=1, path="run")


def docs_page() -> str:
    commands = {item["name"].lower(): item for item in PRODUCT["public_commands"]}
    body = f'''<main id="main"><section class="page-hero"><div class="shell"><p class="eyebrow">Documentation</p><h1>Learn five commands—or simply say “Run Forge.”</h1><p class="lead">The public interface stays small while the advanced assurance engines operate underneath it.</p></div></section><section class="section"><div class="shell doc-layout"><nav class="side" aria-label="Documentation sections"><a href="#start">Start</a><a href="#passport">Passport</a><a href="#help">Help</a><a href="#adopt">Adopt</a><a href="#resume">Resume</a><a href="#check">Check</a><a href="#ship">Ship</a><a href="#advanced">Advanced</a><a href="#limits">Limits</a></nav><article class="prose"><h2 id="start">Start in a chat session</h2><p>Upload the complete project and <code>RUN-FORGE.zip</code>. Tell the active coding AI:</p><pre><code>Run Forge.</code></pre><p>Forge is extracted beside the application, not merged into it. The active AI runs Forge from the target-project root and reads the generated Passport and Resume packet before editing.</p><div class="notice green"><strong>Git is not required.</strong> Forge currently supports folder and ZIP workflows as the primary development path.</div><h2 id="passport">The Project Passport</h2><p>The Passport is the durable project truth. It records project identity, structure, state stores, objective, accepted decisions, safety boundaries, evidence, uncertainty, changed paths, and the next action.</p><p>Forge stores portable working state in <code>.forge/</code>. Deployment packaging excludes both Forge Core and the project’s private Forge state.</p><h2 id="help">Help</h2><p>{esc(commands['help']['description'])}</p><pre><code>{esc(commands['help']['command'])}
forge help check
forge help --project . --json</code></pre><h2 id="adopt">Adopt</h2><p>{esc(commands['adopt']['description'])}</p><pre><code>{esc(commands['adopt']['command'])}</code></pre><p>Adopt records uncertainty rather than silently converting inference into fact. It writes JSON and Markdown Passport files plus the ZIP-era file checkpoint.</p><h2 id="resume">Resume</h2><p>{esc(commands['resume']['description'])}</p><pre><code>{esc(commands['resume']['command'])}
forge resume . --budget compact</code></pre><p>Resume is designed to reduce repeated project rediscovery. Token figures are context-efficiency estimates, not billing guarantees or exact provider tokenization.</p><h2 id="check">Check</h2><p>{esc(commands['check']['description'])}</p><pre><code>forge check . --profile quick
forge check . --profile section</code></pre><p>Quick Check does not imply production readiness. Forge records the scoped result and leaves missing evidence visible.</p><h2 id="ship">Ship</h2><p>{esc(commands['ship']['description'])}</p><pre><code>{esc(commands['ship']['command'])}</code></pre><p>Ship is explicit-only. It runs release proof and confidentiality checks before building the exact artifact and Proof Card.</p><h2 id="advanced">Advanced systems</h2><p>Normal users do not need to learn these first. Advanced users can inspect Graph, Ledger, Lab, runtime contracts, evidence, tool continuity, delivery provenance, and legacy compatibility routes through:</p><pre><code>forge advanced
forge help advanced</code></pre><h2 id="limits">Current limitation</h2><div class="notice"><strong>{esc(VERSION)} is a development preview.</strong> Multi-pass surface discovery and confidence correction are still being hardened. Forge should currently be used as a continuity and control layer, not as the sole production-release authority.</div></article></div></section></main>'''
    return shell("Documentation", "Technical documentation for Run Forge, the Project Passport, and the five-command interface.", body, current="docs", depth=1, path="docs")


def roadmap_page() -> str:
    cards = "".join(
        f'''<article class="release"><strong>{esc(item['version'])}</strong><div><h3>{esc(item['name'])}</h3><p>{esc(item['description'])}</p><code>{esc(item['status'])}</code></div></article>'''
        for item in PRODUCT["roadmap"]
    )
    body = f'''<main id="main"><section class="page-hero"><div class="shell"><p class="eyebrow">Roadmap</p><h1>Continuity first. Commercial release after the foundation is proven.</h1><p class="lead">The website, documentation, public package, and release claims are rebuilt from the same canonical product metadata on every Forge release.</p></div></section><section class="section"><div class="shell"><div class="timeline">{cards}</div></div></section><section class="section alt"><div class="shell grid-2"><article class="card"><span class="num">CURRENT PRIORITY</span><h3>Reliable real-project adoption</h3><p>Strengthen complete surface inventory, confidence correction, and convergence reporting on large unfamiliar projects.</p></article><article class="card"><span class="num">WORKFLOW DECISION</span><h3>ZIP-first through 1.x</h3><p>Git integration is deferred until the v2/commercial-release foundation. Forge must first work exceptionally with folders and ZIP archives.</p></article></div></section></main>'''
    return shell("Roadmap", "The development roadmap for Emotivus Forge.", body, current="roadmap", depth=1, path="roadmap")


def trust_page() -> str:
    body = f'''<main id="main"><section class="page-hero"><div class="shell"><p class="eyebrow">Trust and boundaries</p><h1>Keep project truth without absorbing private projects into Forge.</h1><p class="lead">Forge is public-neutral, local-first, and explicit about the boundary between a host project, Forge Core, working evidence, and final delivery artifacts.</p></div></section><section class="section"><div class="shell grid-2"><article class="card"><span class="num">LOCAL-FIRST</span><h3>Source stays with the project</h3><p>Forge reads the local workspace and stores the project’s Passport in local <code>.forge/</code> state. It does not require a hosted Forge service.</p></article><article class="card"><span class="num">PUBLIC-NEUTRAL</span><h3>No customer project data in Forge Core</h3><p>Public distributions use neutral synthetic fixtures or properly licensed public projects and must not contain host source, secrets, datasets, tests, or identifiable implementation details.</p></article><article class="card"><span class="num">MODEL-INDEPENDENT</span><h3>No AI lock-in</h3><p>The same Passport and Resume packet can guide ChatGPT, Claude, Cursor, another coding agent, or a human developer.</p></article><article class="card"><span class="num">EXACT CLAIMS</span><h3>Unknown remains unknown</h3><p>Forge distinguishes source validity, executed entrypoints, upgrade state, target environment, confidentiality, and final delivery proof instead of using one universal green badge.</p></article></div></section><section class="section alt"><div class="shell"><div class="section-head"><div><p class="eyebrow">Smart-start safety boundary</p><h2>“Run Forge” is intentionally non-destructive.</h2></div><p>The natural-language startup can Adopt, Resume, or perform Quick Check. Higher-risk operations remain explicit.</p></div><div class="trust-strip"><div><b>No automatic Ship</b><span>Release packaging requires an explicit command.</span></div><div><b>No automatic deploy</b><span>Forge does not publish or upload the application.</span></div><div><b>No production migration</b><span>Persisted-state changes require explicit control.</span></div><div><b>No blocker bypass</b><span>Failed or missing evidence stays visible.</span></div></div></div></section><section class="section"><div class="shell prose"><h2>Current public status</h2><p><strong>{esc(VERSION)}</strong> is a development preview. It is appropriate for project continuity and control testing. It is not a commercial release, a guarantee of complete project understanding, or the sole authority for production readiness.</p><h2>Official public location</h2><p>Forge lives at <a class="site-domain" href="{esc(BASE_URL)}">{esc(BASE_URL)}</a> as part of <a href="https://emotivus.com">Emotivus</a>.</p></div></section></main>'''
    return shell("Trust", "Privacy, neutrality, safety boundaries, and honest proof for Emotivus Forge.", body, current="trust", depth=1, path="trust")


def changelog_page() -> str:
    highlights = "".join(f"<li>{esc(item)}</li>" for item in PRODUCT["release_highlights"])
    body = f'''<main id="main"><section class="page-hero"><div class="shell"><p class="eyebrow">Changelog</p><h1>{esc(VERSION)} · Branded public website integration</h1><p class="lead">The champion Tempered Continuity identity now governs Forge’s public website and generated release documentation.</p></div></section><section class="section"><div class="shell prose"><h2>Current release highlights</h2><ul>{highlights}</ul><h2>Website integration</h2><ul><li>Official public domain configured as <code>forge.emotivus.com</code>.</li><li>Home, Run Forge, Documentation, Roadmap, Trust, Changelog, and Download destinations generated from canonical product data.</li><li>Champion continuity-ring logo, favicon, responsive design system, and accessible navigation integrated.</li><li>Website version, limitations, roadmap, commands, and release status remain release-bound instead of manually drifting.</li></ul><h2>Current boundary</h2><p>Multi-pass surface discovery remains in development. The website does not market Forge as commercially released or as a guarantee of production readiness.</p></div></section></main>'''
    return shell("Changelog", "Release history and current development changes for Emotivus Forge.", body, current="roadmap", depth=1, path="changelog")


def write_support_files(download: Path | None, release_notes: Path | None, checksums: Path | None) -> None:
    if download and download.is_file():
        shutil.copy2(download, SITE / "downloads" / "RUN-FORGE.zip")
    else:
        placeholder = SITE / "downloads" / "RUN-FORGE.zip"
        if placeholder.exists():
            placeholder.unlink()
    if release_notes and release_notes.is_file():
        shutil.copy2(release_notes, SITE / "downloads" / "RELEASE-NOTES.md")
    else:
        (SITE / "downloads" / "RELEASE-NOTES.md").write_text(
            f"# Emotivus Forge {VERSION}\n\nSee the packaged release for current certification evidence.\n",
            encoding="utf-8",
        )
    if checksums and checksums.is_file():
        shutil.copy2(checksums, SITE / "downloads" / "SHA256SUMS.txt")
    else:
        lines = []
        for name in ("RUN-FORGE.zip", "RELEASE-NOTES.md"):
            path = SITE / "downloads" / name
            if path.is_file():
                lines.append(f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {name}")
        (SITE / "downloads" / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def build(download: Path | None = None, release_notes: Path | None = None, checksums: Path | None = None) -> None:
    for directory in ("run", "docs", "roadmap", "trust", "changelog", "downloads"):
        (SITE / directory).mkdir(parents=True, exist_ok=True)
    (SITE / "index.html").write_text(home(), encoding="utf-8")
    (SITE / "run" / "index.html").write_text(run_page(), encoding="utf-8")
    (SITE / "docs" / "index.html").write_text(docs_page(), encoding="utf-8")
    (SITE / "roadmap" / "index.html").write_text(roadmap_page(), encoding="utf-8")
    (SITE / "trust" / "index.html").write_text(trust_page(), encoding="utf-8")
    (SITE / "changelog" / "index.html").write_text(changelog_page(), encoding="utf-8")
    (SITE / "robots.txt").write_text(f"User-agent: *\nAllow: /\nSitemap: {BASE_URL}/sitemap.xml\n", encoding="utf-8")
    urls = ["", "run", "docs", "roadmap", "trust", "changelog"]
    sitemap = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + "".join(
        f"  <url><loc>{esc(canonical(path))}</loc></url>\n" for path in urls
    ) + "</urlset>\n"
    (SITE / "sitemap.xml").write_text(sitemap, encoding="utf-8")
    manifest = {
        "name": "Emotivus Forge",
        "short_name": "Forge",
        "start_url": "/",
        "display": "standalone",
        "background_color": "#090706",
        "theme_color": "#090706",
        "icons": [{"src": "assets/favicon.svg", "sizes": "any", "type": "image/svg+xml"}],
    }
    (SITE / "site.webmanifest").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    write_support_files(download, release_notes, checksums)
    print(f"Built Forge public website for {VERSION} at {BASE_URL}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--download", type=Path, help="Optional RUN-FORGE.zip to place in website downloads")
    parser.add_argument("--release-notes", type=Path, help="Optional release notes Markdown")
    parser.add_argument("--checksums", type=Path, help="Optional checksum file")
    args = parser.parse_args()
    build(args.download, args.release_notes, args.checksums)


if __name__ == "__main__":
    main()
