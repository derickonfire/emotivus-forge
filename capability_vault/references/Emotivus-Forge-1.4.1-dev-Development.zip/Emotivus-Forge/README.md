# Emotivus Forge 1.4.1-dev

## Five commands. One Project Passport. Any coding AI.

**The portable project memory, token-efficiency, control, and proof layer for AI-built software.**

Forge is designed for projects that have become too large, old, multi-session, or AI-dependent to control reliably through chat history and ZIP filenames alone.

Forge does not replace the coding AI. It gives the project a durable operating memory and an evidence boundary around the AI:

- what the project is;
- how to avoid repeatedly spending context rebuilding what the project is;
- what surfaces and state it contains;
- what objective is active;
- what decisions and defects must survive session changes;
- what files changed between Forge observations, even without Git;
- what those changes affect;
- what has actually been executed and proven;
- what remains unknown;
- which exact ZIP is safe to deliver.

## What Forge actually is

Forge is a portable local command-line control layer. The active coding AI, developer, or project operator runs Forge inside the project workspace.

It is not:

- another coding model;
- a hosted service that takes ownership of the project;
- a requirement to use Git;
- a system that copies private host source into the Forge product.

Forge inspects the working project, writes project-specific continuity and evidence metadata into `.forge/`, and keeps the reusable Forge Core neutral and portable.

## How to use Forge with an AI project

For first contact, provide the active AI with the fully extracted application source and the Forge ZIP. Then use one instruction:

```text
Run Forge.
```

The active AI extracts Forge beside the project and runs from the host-project root:

```bash
python3 Emotivus-Forge/forge.py
```

Forge automatically chooses Adopt + Resume, Resume, or Quick Check + Resume. It never automatically Ships, deploys, deletes, runs production migrations, or applies environment repairs. Read `.forge/passport/resume.md` before changing code.

The expected layout is:

```text
Working-Project/
├── Emotivus-Forge/
├── .forge/
└── application source...
```

Keep `.forge/` with the working project between AI sessions. The deployment ZIP produced by Ship excludes Forge Core and private working state from the deployable application.

`adopt` is intentionally the product term. Forge adopts responsibility for understanding and tracking the project; it does not “absorb” the project into Forge Core.

The canonical launcher is `forge.py`. An optional `frg` launcher alias is retained only for environments where another local tool already owns the name `forge`; it does not add commands or change the five-command product model.

## The five-command interface

### 1. Help

```bash
python3 Emotivus-Forge/forge.py help --project .
python3 Emotivus-Forge/forge.py help check
```

Help is the explicit read-only guide. The only first instruction a user must remember is “Run Forge.” It safely inspects whether Forge has adopted the project, reports the objective, changed-path count, and strongest proof claim, then recommends one exact next command with a reason. Topic help documents each normal command without exposing internal engine names.

Help is read-only. It does not initialize, test, modify, or package the host project.

### 2. Adopt

```bash
python3 Emotivus-Forge/forge.py adopt .
```

Adopt initializes or refreshes Forge around an existing project. It inventories the workspace, detects runtimes and tools, builds the project graph, records uncertainty, establishes the first file-hash checkpoint, and creates the Project Passport.

Primary outputs:

```text
.forge/passport/passport.json
.forge/passport/passport.md
.forge/passport/adopted-snapshot.json
```

### 3. Resume

```bash
python3 Emotivus-Forge/forge.py resume . --budget compact
```

Resume creates the minimum sufficient continuation packet for the next AI or human. It combines the current objective, active plan or pivot, durable project records, relevant architecture, learned contracts, changed paths, evidence gaps, and the next action.

Primary outputs:

```text
.forge/passport/resume.json
.forge/passport/resume.md
```

### 4. Check

```bash
python3 Emotivus-Forge/forge.py check . --profile quick
python3 Emotivus-Forge/forge.py check . --profile section
```

Check compares the current project to the previous Forge observation without requiring Git. It calculates impact for changed paths, runs the requested proof profile, rebuilds release coverage, and advances the observed checkpoint.

A passing Quick Check means only that the Quick profile passed. It does **not** imply upgrade safety, target-environment parity, final-artifact integrity, or production readiness.

### 5. Ship

```bash
python3 Emotivus-Forge/forge.py ship .
```

Ship runs fresh Release proof, evaluates the requested release claim, runs confidentiality checks, and builds the exact deployment ZIP only when the boundary is supported. It writes a Proof Card whether shipping passes or is blocked.

Primary outputs:

```text
.forge/passport/proof-card.json
.forge/passport/proof-card.md
deploy/<project>-<version>.zip
```


## Major token-conservation benefit

Large AI-built projects repeatedly waste context when every new session rereads source, reconstructs architecture, rediscovers prior decisions, and re-explains completed work. Forge Resume replaces that broad reload with a bounded packet of minimum sufficient verified project truth.

Resume reports:

- the packet's estimated token count and configured budget;
- a project-wide token-equivalent baseline derived from the current file snapshot;
- estimated repeated context avoided and reduction percentage;
- the estimation method and its limitations.

The default compact Resume budget is 1,200 estimated tokens. The comparison is a planning heuristic—not a provider billing guarantee or exact tokenizer measurement. Forge must never conserve tokens by hiding critical uncertainty, defects, state transitions, or release evidence.

See [`docs/TOKEN-CONSERVATION.md`](docs/TOKEN-CONSERVATION.md).

## Advanced controls

Normal Forge use requires only Help, Adopt, Resume, Check, and Ship. Expert diagnostics and maintenance remain available through:

```bash
python3 Emotivus-Forge/forge.py advanced
```

This catalog exposes Graph, Doctor, evidence inspection, Labs, confidentiality, updates, documentation, and transitional 1.3.x compatibility routes. These capabilities remain underneath the four project outcomes and are not part of normal onboarding.

## Project Passport

The Project Passport is Forge’s primary user object. It contains:

- project identity and version;
- workspace classification and confidence;
- runtime requirements and deployment target;
- graph and surface summary;
- objective, active plan, active pivot, and durable records;
- last green evidence and changed-since-green state;
- file-level changes since the previous Forge checkpoint;
- environment, source-completeness, packaging, and coverage uncertainties;
- strongest supported release claim;
- exact recommended next action.

See [`docs/PROJECT-PASSPORT.md`](docs/PROJECT-PASSPORT.md).

## No Git requirement

Forge 1.x is intentionally usable with folder and ZIP-based development. It stores deterministic per-file hashes in `.forge/passport/` and compares them between Adopt, Resume, and Check operations.

The intended near-term workflow is:

```text
Project source folder
    ↓
Forge Passport and Check
    ↓
Forge-generated development or deployment ZIP
    ↓
cPanel, staging, or handoff
```

Optional Git-aware continuity is deferred until the v2 commercial foundation. Git is not required for 1.4 development.

## Advanced assurance engines

The previous named capabilities still exist and remain callable for compatibility:

- Graph and surface inventory;
- Ledger, plans, pivots, and context packets;
- Impact, Learn, and Guardrails;
- Gate, Lab, runtime contracts, and release proof;
- confidentiality and delivery provenance;
- tool-ecosystem migration and continuity;
- Mirror self-certification, CI bridges, and state export.

They are internal engines or advanced diagnostics rather than the normal product journey. See [`docs/ADVANCED-CAPABILITIES.md`](docs/ADVANCED-CAPABILITIES.md).

## Website and documentation

The public documentation site is generated from [`FORGE-PRODUCT.json`](FORGE-PRODUCT.json):

```bash
python3 docs-site/build_site.py
python3 forge.py docs --serve
```

A development release is incomplete when the generated website advertises an older version, command set, roadmap, or limitation statement.

## Safety and neutrality

Forge Core must remain public and neutral. It must never absorb or distribute:

- host project source;
- private datasets or production records;
- credentials or secrets;
- proprietary tests or fixtures;
- identifiable implementation details from a private project.

Public validation uses neutral synthetic fixtures or properly licensed public projects. Forge state records metadata, hashes, classifications, evidence references, and project-relative paths—not copies of private host source.

## Bounded execution and resume

Forge does not treat a long run killed by its host as a pass. Its self-tests execute as isolated, checkpointed shards:

```bash
python3 forge.py self-test --fresh --budget-seconds 30
python3 forge.py self-test --resume --budget-seconds 30
```

A host budget returns `INCOMPLETE`; a per-shard overrun returns `TIMEOUT`. See `docs/EXECUTION-CONTROL.md`.

## Development status

Forge 1.4.1-dev implements the first-target smart-start layer above the product pivot foundation. It is not a commercial release.

The highest-priority remaining work is:

1. multi-pass surface discovery and correction;
2. stronger Graph-to-evidence dependency joins;
3. project-size and continuation-quality controls;
4. exact Changed Files ZIP generation inside Ship;
5. broader unfamiliar-project and persisted-state battle testing.

Read [`ROADMAP.md`](ROADMAP.md) and [`FORGE-PRODUCT.json`](FORGE-PRODUCT.json) for the canonical current direction.
## Public website

The official Forge website is generated for `https://forge.emotivus.com`. Its content, public commands, roadmap, limitations, trust boundaries, and release status come from `FORGE-PRODUCT.json`.

```bash
python3 docs-site/build_site.py
```

The release website includes Home, Run Forge, Documentation, Roadmap, Trust, Changelog, and Downloads. A Forge release is incomplete when this generated site is stale. See `docs/WEB-DOCUMENTATION.md` and `docs/BRAND-IDENTITY.md`.

