# Emotivus Forge Development Roadmap

Forge is now organized around one primary object—the **Project Passport**—and five commands: **Help, Adopt, Resume, Check, and Ship**. Help is the explicit read-only guide; the natural first instruction is **“Run Forge.”** The other four commands remain the project outcomes.

The former Understand / Change / Prove model and its named capabilities remain available only as advanced engines and compatibility routes.

## 1.4.0-dev — Pivot Foundation · Completed

Implemented in this release:

- public `help`, `adopt`, `resume`, `check`, and `ship` commands;
- read-only guided Help with project-state inspection and one exact next-command recommendation;
- Project Passport JSON and Markdown outputs;
- canonical `forge` launcher with `frg` retained only as an optional name-conflict alias;
- measured Resume token-efficiency baseline and reduction reporting;
- per-file hash checkpoints and changed-path detection without Git;
- change-aware graph impact before proof;
- scoped Proof Card generation for Ship pass or block;
- canonical `FORGE-PRODUCT.json` metadata;
- generated multi-page documentation website;
- hidden compatibility access to the 1.3.x engines;
- updated onboarding, bootstrap instructions, and self-hosted Lab recipes.

Known limitations:

- first-pass graph and surface classification can still miss or misclassify uncommon application surfaces;
- Check records changed files, but evidence dependency invalidation is not yet fully typed at the node-to-claim level;
- Ship creates the deployment ZIP but does not yet create a separate Changed Files ZIP as a first-class output;
- continuation quality is not yet scored against large-project completeness criteria.

## 1.4.1-dev — Run Forge + Reliable Adoption · Current

Goal: make first contact effortless, then make the Project Passport trustworthy before adding more visible features.

Implemented for the first field target:

- the two-word user instruction **“Run Forge”**;
- safe zero-command selection of Adopt + Resume, Resume, or Quick Check + Resume;
- automatic generation of the current Resume packet;
- explicit prohibition on automatic Ship, deployment, deletion, production migration, or environment repair;
- self-describing first-contact instructions inside the ZIP.

Continuing in this development line:

- bounded multi-pass discovery that continues until the inventory converges;
- confirmed, inferred, uncertain, corrected, and rejected classifications;
- comprehensive browser, API, CLI, webhook, worker, scheduled-job, migration, installer, and deployment surface inventory;
- manifest and framework registration discovery;
- false-positive suppression without hiding uncertain surfaces;
- correction records that generalize rather than memorize one fixture;
- adoption report showing what changed between discovery passes;
- explicit completeness and confidence boundaries.

## 1.4.2-dev — Continuation Control

Goal: make Forge immediately useful when a large project becomes difficult for an AI to control.

- objective authority and source-of-truth ranking;
- active-versus-archived plan separation;
- task-scoped file retrieval and context budgeting;
- real-world token-efficiency benchmarks across small, medium, and large projects;
- project-size indicators and context-pressure warnings;
- contradiction detection across plans, documentation, release metadata, and code;
- unresolved decision and dependency queues;
- session handoff completeness checks;
- concise AI adapter files generated from the same Passport rather than independent instruction sets.

## 1.4.3-dev — Change-Aware Proof

Goal: connect every change to the evidence that became stale.

- typed Graph-to-evidence joins;
- file, surface, state, environment, and artifact evidence dependencies;
- automatic invalidation after relevant changes;
- impact-selected Quick and Section proof plans;
- explicit unaffected-evidence reuse with fingerprint checks;
- coverage matrices by surface, state, runtime, and claim;
- unresolved evidence debt visible in the Passport.

## 1.4.4-dev — Exact Ship

Goal: make ZIP delivery defensible and easy.

- Full Release ZIP;
- Changed Files ZIP;
- portable Forge State archive;
- release manifest and SHA-256 checksums;
- exact source-to-package provenance;
- migration and deployment instructions;
- confidentiality and secret scan of source and final archive;
- shareable Proof Card;
- final-byte revalidation after packaging;
- cPanel-friendly deployment profile without requiring Git.

## 1.5-beta — Field Validation

Goal: prove that Forge improves unfamiliar real projects rather than only Forge’s own fixtures.

- neutral synthetic failure laboratories;
- properly licensed public-project trials;
- large-project continuation tests across multiple AI sessions;
- prior-state and partial-migration matrices;
- target runtime and extension parity trials;
- measured discovery recall, precision, false positives, and unresolved classifications;
- usability testing of Help, Adopt, Resume, Check, and Ship;
- documentation accessibility and installation review.

## 1.6-rc — Public Release Candidate

- installation and upgrade contracts;
- license selection;
- security and privacy documentation;
- platform compatibility matrix;
- public download, checksums, changelog, and support boundaries;
- stable config and Passport schemas;
- migration path from 1.3.x and 1.4.x development states.

## 2.0 — Commercial Release Foundation

- stable public Project Passport product;
- polished installer and updater;
- optional Git-aware continuity and provider integrations;
- commercial packaging and support model;
- mature public website and documentation;
- independently reproducible release certification.

Git is deliberately deferred. Forge must first be excellent for the ZIP and folder workflow already used by its target users.
