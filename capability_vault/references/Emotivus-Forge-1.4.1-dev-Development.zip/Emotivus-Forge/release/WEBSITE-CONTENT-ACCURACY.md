# Website Content Accuracy Contract

The public website must state:

- Forge is a portable local project-memory and proof layer.
- The first instruction is “Run Forge.”
- Help, Adopt, Resume, Check, and Ship are the five public commands.
- Smart startup may automatically Adopt, Resume, or Quick Check.
- Ship, deployment, production migration, deletion, environment repair, and blocker bypass are explicit-only.
- Git is not required in the current ZIP-first development workflow.
- Forge is a development preview and not the sole production-readiness authority.
- Multi-pass surface discovery remains under active hardening.

The website must not state or imply:

- automatic code generation or repair by Forge itself;
- guaranteed bug-free software;
- complete project discovery today;
- automatic deployment;
- commercial-release availability;
- customer project data being included in Forge Core.
