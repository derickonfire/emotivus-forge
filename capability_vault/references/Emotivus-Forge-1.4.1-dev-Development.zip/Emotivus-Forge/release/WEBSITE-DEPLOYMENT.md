# Deploying the Forge Website

Target: `https://forge.emotivus.com`

1. Point the subdomain document root to a dedicated directory in cPanel.
2. Upload the contents of the standalone Forge website ZIP into that document root.
3. Confirm HTTPS is active.
4. Verify Home, Run Forge, Documentation, Roadmap, Trust, Changelog, and Downloads.
5. Download `RUN-FORGE.zip` from the live site and compare its SHA-256 value with `downloads/SHA256SUMS.txt`.
6. Check mobile navigation, copy buttons, favicon, `robots.txt`, and `sitemap.xml`.

Do not upload the full development source tree into the public website document root.
