# Emotivus Forge 1.4.1-dev — Website-Integrated First Target

## Primary product contract

The first instruction is:

> **Run Forge.**

Smart startup safely selects Adopt + Resume, Resume, or Quick Check + Resume. Help, Adopt, Resume, Check, and Ship remain the complete five-command public interface.

## Website integration

- Official public location: `https://forge.emotivus.com`
- Official identity: **Tempered Continuity**
- Generated destinations: Home, Run Forge, Documentation, Roadmap, Trust, Changelog, and Downloads
- Canonical product source: `FORGE-PRODUCT.json`
- Responsive mobile navigation, SVG logo/favicons, robots, sitemap, web manifest, release downloads, and checksum links
- Website accuracy, public limitations, trust boundaries, and download contract covered by Forge regression

## Certification target

- 184 neutral regressions represented
- 48 bounded resumable shards
- Public and development archive confidentiality checks
- Independent packaged startup smoke
- Static website link and artifact verification

## Current limitation

Complete multi-pass surface discovery and confidence correction remain active 1.4.x development. Forge is ready for project continuity and control testing, not as the sole production-readiness authority.
