# Emotivus Forge 1.4.1-dev Public Preview

This is a neutral development preview for first-target field testing. It is not a commercial release and does not guarantee complete project understanding or production readiness.

First instruction:

> **Run Forge.**

The zero-command launcher may Adopt, Resume, or perform Quick Check. Ship, deployment, deletion, production migration, and environment repair require explicit instruction.

Keep host-project source and `.forge/` state with the host project. Do not copy private host source, datasets, tests, credentials, or identifiable implementation details into Forge Core, public examples, documentation, or distributions.
## Public website

The generated public website targets `https://forge.emotivus.com` and uses the official Tempered Continuity identity. Website content is release-bound through `FORGE-PRODUCT.json`; it remains a development-preview site and does not claim commercial availability or complete production assurance.

